import Head from 'next/head'
// import Image from 'next/image'
import Navbar from '../components/Navbar'
import styles from '../styles/Home.module.css'
import BigLogo from '../public/utils/BigLogo.png'
import LandingScreen from '../components/LandingScreen'
import { Box } from '@mui/material'


export default function Home() {
  return (
    <Box>
      <Navbar />
      <LandingScreen />

    </Box>
  )
}