import React from 'react'
import { Grid, Typography, Button, Box } from '@mui/material'
import Image from 'next/image'

const LandingScreen = () => {
    return (

        <Grid container spacing={2} sx={{ display: 'flex', justifyContent: 'center' }}>
            <Grid item xs={12} sm={5} sx={{ rowGap: '20px', height: `calc(100vh -  110px)`, display: 'flex', flexDirection: 'column', alignItems: 'flex-start', justifyContent: 'center', border: '1px solid black' }}>
                <Typography variant='h3' sx={{ color: '#120155', fontWeight: 'bold', letterSpacing: '1px' }}>Don't just Integrate</Typography>
                <Typography variant='h3' sx={{ color: '#5856ce', fontWeight: 'bold', letterSpacing: '1px' }}>Accelerate your CRM</Typography>
                <Typography sx={{ fontSize: '18px', }}>Propel your sales team into a state of flow with CRM Accelerations. Switch out boring hours of repetitive work with high-impact activities. Build a repeatable sales process.</Typography>
                <Button variant='contained' sx={{ color: '#d3d3f2', bgcolor: '#5856ce', ':hover': { bgcolor: '#5856ce' } }}>Get started</Button>
            </Grid>
            <Grid item xs={12} sm={5} sx={{ height: `calc(100vh -  110px)`, border: '1px solid black', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Image src='/../public/utils/Group 1006.png' width='500' height='500' />
            </Grid>
        </Grid>


    )
}

export default LandingScreen