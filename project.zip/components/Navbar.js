import { AppBar, Toolbar, Box, Button } from '@mui/material'
import React from 'react'
import Image from 'next/image'


const navList = ['Platform', 'Pricing', 'Acceleration', 'Resource', 'Custom Stories']

const linkStyle = { color: '#120155', fontWeight: 'bold', cursor: 'pointer', fontSize: '16px' }
const Navbar = () => {
    return (

        <AppBar position="static" color='transparent' sx={{ border: '1px solid black', boxShadow: 'none', }}>
            <Toolbar sx={{ height: '120px' }}>
                <Box sx={{ display: 'flex', columnGap: '40px', flexGrow: 1, alignItems: 'center' }}>
                    <Image src='/../public/utils/BigLogo.png' width='129px' height='60px' />
                    <Box sx={{ display: 'flex', columnGap: '25px', alignItems: 'flex-end' }}>
                        {navList.map((list, index) => <span key={index} style={linkStyle}>{list}</span>)}
                    </Box>
                </Box>

                <Box sx={{ display: 'flex', columnGap: '15px', alignItems: 'center' }}>
                    <span style={{ ...linkStyle, fontSize: '18px' }}>Log in</span>
                    <Button variant="text" sx={{ color: '#5856ce', border: '1px solid #5856ce' }} >Schedule Demo</Button>
                    <Button variant="contained" sx={{ color: '#d3d3f2', bgcolor: '#5856ce', ':hover': { bgcolor: '#5856ce' } }}>Try For Free</Button>
                </Box>

            </Toolbar>
        </AppBar>

    )
}

export default Navbar